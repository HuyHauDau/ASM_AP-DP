﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using static ASM1_SIMS.Program;

namespace ASM1_SIMS
{

    using System;
    using System.Collections.Generic;

    // Abstract base class for entities
    public abstract class EntityBase
    {
        public string Name { get; set; }
        // ... other common properties and methods
    }

    // Interface for displayable entities
    public interface IDisplayable
    {
        void DisplayDetails();
    }

    // Person class implementing the EntityBase and IDisplayable
    public class Person : EntityBase, IDisplayable
    {
        public void DisplayDetails()
        {
            Console.WriteLine($"Person - Name: {Name}");
        }
    }

    // Teacher class implementing the EntityBase and IDisplayable
    public class Teacher : Person
    {
        public void DisplayDetails()
        {
            base.DisplayDetails();
            Console.WriteLine($"Teacher");
        }
    }

    // Student class implementing the EntityBase and IDisplayable
    public class Student : Person
    {
        public void DisplayDetails()
        {
            base.DisplayDetails();
            Console.WriteLine($"Student");
        }
    }

    // Department class implementing the EntityBase, IDisplayable, and aggregating Teachers
    public class Department : EntityBase, IDisplayable
    {
        public List<Teacher> Teachers { get; set; } = new List<Teacher>();

        public void DisplayDetails()
        {
            Console.WriteLine($"Department - Name: {Name}");
            Console.WriteLine("Teachers:");
            foreach (var teacher in Teachers)
            {
                teacher.DisplayDetails();
            }
        }
    }

    // Course class implementing the EntityBase, IDisplayable, and aggregating Students
    public class Course : EntityBase, IDisplayable
    {
        public List<Student> Students { get; set; } = new List<Student>();

        public void DisplayDetails()
        {
            Console.WriteLine($"Course - Name: {Name}");
            Console.WriteLine("Students:");
            foreach (var student in Students)
            {
                student.DisplayDetails();
            }
        }
    }

    // Client code
    class Program

    {
        private static void Main()
        {
            // Example usage
            Teacher AITeacher = new Teacher { Name = "Ta Quang Hieu" };
            Teacher BITeacher = new Teacher { Name = "Dinh Van Dong" };

            Department ITDepartment = new Department { Name = "Semiconductor Technology" };
            ITDepartment.Teachers.Add(BITeacher);
            ITDepartment.Teachers.Add(AITeacher);

            Student BIStudent = new Student { Name = "Le Minh Phuc" };
            Student AIStudent = new Student { Name = "Tran Van Khiem" };

            Course ITCourse = new Course { Name = "IT0601 - course 4" };
            ITCourse.Students.Add(BIStudent);
            ITCourse.Students.Add(AIStudent);

            // Display details
            ITDepartment.DisplayDetails();
            Console.WriteLine();
            ITCourse.DisplayDetails();

            // Keep the console window open to view the output
            Console.ReadLine();
        }
    }


}
