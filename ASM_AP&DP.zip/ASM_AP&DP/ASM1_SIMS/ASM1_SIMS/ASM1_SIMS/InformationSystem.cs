﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ASM1_SIMS
{
    internal class Class1
    {
        public class InformationSystem
        {
            public void PrintPersonDetails(Person person)
            {
                person.DisplayDetails();
            }
        }
    }
}
