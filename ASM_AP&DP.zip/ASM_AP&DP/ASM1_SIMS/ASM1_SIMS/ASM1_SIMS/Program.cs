﻿using System;

// Base class for a person
public class Person
{
    // Encapsulated properties
    public string Name { get; set; }
    private int Age { get; set; }

    // Constructor
    public Person(string name, int age)
    {
        Name = name;
        Age = age;
    }

    // Encapsulated method to get age
    public int GetAge()
    {
        return Age;
    }
}

// Class for representing a teacher
public class Teacher : Person
{
    public string EmployeeId { get; set; }

    // Constructor
    public Teacher(string name, int age, string employeeId) : base(name, age)
    {
        EmployeeId = employeeId;
    }
}

// Class for representing a student
public class Student : Person
{
    public string StudentId { get; set; }

    // Constructor
    public Student(string name, int age, string studentId) : base(name, age)
    {
        StudentId = studentId;
    }
}

// Class for representing an account
public class Account
{
    private double balance;

    // Encapsulated property
    public double Balance
    {
        get { return balance; }
        set
        {
            // Additional logic can be added, e.g., validation
            if (value >= 0)
            {
                balance = value;
            }
        }
    }
}

// Class for representing a department
public class Department
{
    public string DepartmentName { get; set; }
}

// Class for representing a course
public class Course
{
    public string CourseCode { get; set; }
    public string CourseName { get; set; }
    private Department Department { get; set; }

    // Encapsulated property with validation
    public Department AssociatedDepartment
    {
        get { return Department; }
        set
        {
            if (value != null)
            {
                Department = value;
            }
        }
    }
}

// Class for representing a subject
public class Subject
{
    public string SubjectCode { get; set; }
    public string SubjectName { get; set; }
}
