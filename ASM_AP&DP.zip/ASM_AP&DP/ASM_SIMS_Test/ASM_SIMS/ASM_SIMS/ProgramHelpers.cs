﻿using static ASM_SIMS.UnitTest1;

internal static class ProgramHelpers
{

    public static void Main()
    {
        // Example usage
        SIMS sims = new SIMS();

        Teacher teacher = new Teacher { Id = 1, Name = "Dinh Van Dong", Age = 35, EmployeeId = "001" };
        sims.AddTeacher(teacher);

        Student student = new Student { Id = 2, Name = "Le Minh Phuc", Age = 19, StudentId = "BH01208" };
        sims.AddStudent(student);

        sims.DisplayPeopleDetails(); // Display details of all people in the system

        Console.ReadLine();
    }
}