using System;
namespace ASM_SIMS
{
    public class UnitTest1
    {
        [Fact]
        public void Test1()
        { }




        public class Person
        {
            public int Id { get; set; }
            public string Name { get; set; }
            public int Age { get; set; }

            public virtual void DisplayDetails()
            {
                Console.WriteLine($"ID: {Id}, Name: {Name}, Age: {Age}");
            }
        }

        // Derived class for Teacher, inherits from Person
        public class Teacher : Person
        {
            public string EmployeeId { get; set; }

            // Additional properties and methods specific to Teacher
        }

        // Derived class for Student, inherits from Person
        public class Student : Person
        {
            public string StudentId { get; set; }

            // Additional properties and methods specific to Student
        }

        // Class for Account
        public class Account
        {
            public string Username { get; set; }
            public string Password { get; set; }

            // Additional properties and methods related to authentication
        }

        // Class for Department
        public class Department
        {
            public int DepartmentId { get; set; }
            public string DepartmentName { get; set; }

            // Additional properties and methods related to Department
        }

        // Class for Course
        public class Course
        {
            public int CourseId { get; set; }
            public string CourseName { get; set; }

            // Additional properties and methods related to Course
        }

        // Class for Subject
        public class Subject
        {
            public int SubjectId { get; set; }
            public string SubjectName { get; set; }

            // Additional properties and methods related to Subject
        }

        // Student Information Management System
        public class SIMS
        {
            private List<Person> people;
            private List<Teacher> teachers;
            private List<Student> students;
            private List<Department> departments;
            private List<Course> courses;
            private List<Subject> subjects;

            public SIMS()
            {
                people = new List<Person>();
                teachers = new List<Teacher>();
                students = new List<Student>();
                departments = new List<Department>();
                courses = new List<Course>();
                subjects = new List<Subject>();
            }

            // Encapsulation: Adding people to the system
            public void AddPerson(Person person)
            {
                people.Add(person);
            }

            // Encapsulation: Displaying details of all people in the system
            public void DisplayPeopleDetails()
            {
                foreach (var person in people)
                {
                    person.DisplayDetails();
                }
            }

            // Encapsulation: Finding a person by ID
            public Person FindPersonById(int id)
            {
                return people.Find(p => p.Id == id);
            }

            // Polymorphism: Displaying details of a specific person
            public void DisplayPersonDetails(Person person)
            {
                person.DisplayDetails();
            }

            // Encapsulation: Adding a teacher to the system
            public void AddTeacher(Teacher teacher)
            {
                teachers.Add(teacher);
                AddPerson(teacher); // Reusing the AddPerson method
            }

            // Encapsulation: Adding a student to the system
            public void AddStudent(Student student)
            {
                students.Add(student);
                AddPerson(student); // Reusing the AddPerson method
            }

            // Abstraction: Other methods for managing departments, courses, subjects, etc.
        }

    }

}
